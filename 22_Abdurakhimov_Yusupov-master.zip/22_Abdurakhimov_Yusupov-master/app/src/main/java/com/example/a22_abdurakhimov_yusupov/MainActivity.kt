package com.example.a22_abdurakhimov_yusupov

import android.os.Bundle
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private lateinit var mGrid: GridView
    private lateinit var mAdapter: GridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mGrid = findViewById(R.id.field)
        mAdapter = GridAdapter(this, 6, 6)
        mGrid.adapter = mAdapter

        mGrid.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            mAdapter.checkOpenCells()
            mAdapter.openCell(position)

            if (mAdapter.checkGameOver()) {
                Toast.makeText(this, "Игра закончена", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

