package com.example.a22_abdurakhimov_yusupov
import android.content.Context
import android.content.res.Resources
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import java.util.*

class GridAdapter(private val context: Context, private val cols: Int, private val rows: Int) : BaseAdapter() {

    private val arrPict = ArrayList<String>()
    private val arrStatus = ArrayList<Status>()
    private val pictureCollection = "animal"
    private val mRes: Resources = context.resources

    init {
        makePictArray()
        closeAllCells()
    }

    private fun makePictArray() {
        arrPict.clear()
        for (i in 0 until (cols * rows) / 2) {
            arrPict.add("$pictureCollection$i")
            arrPict.add("$pictureCollection$i")
        }
        Collections.shuffle(arrPict)
    }

    private fun closeAllCells() {
        arrStatus.clear()
        for (i in 0 until cols * rows) {
            arrStatus.add(Status.CELL_CLOSE)
        }
    }

    override fun getCount(): Int {
        return cols * rows
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: ImageView = if (convertView == null) {
            ImageView(context)
        } else {
            convertView as ImageView
        }

        when (arrStatus[position]) {
            Status.CELL_OPEN -> {
                val drawableId = mRes.getIdentifier(arrPict[position], "drawable", context.packageName)
                view.setImageResource(drawableId)
            }
            Status.CELL_CLOSE -> {
                view.setImageResource(R.drawable.img_2)
            }
            else -> {
                view.setImageResource(R.drawable.img)
            }
        }

        return view
    }

    fun checkOpenCells() {
        val first = arrStatus.indexOf(Status.CELL_OPEN)
        val second = arrStatus.lastIndexOf(Status.CELL_OPEN)
        if (first == second) return
        if (arrPict[first] == arrPict[second]) {
            arrStatus[first] = Status.CELL_DELETE
            arrStatus[second] = Status.CELL_DELETE
        } else {
            arrStatus[first] = Status.CELL_CLOSE
            arrStatus[second] = Status.CELL_CLOSE
        }
    }

    fun openCell(position: Int) {
        if (arrStatus[position] != Status.CELL_DELETE) {
            arrStatus[position] = Status.CELL_OPEN
        }
        notifyDataSetChanged()
    }

    fun checkGameOver(): Boolean {
        return arrStatus.indexOf(Status.CELL_CLOSE) < 0
    }

    private enum class Status {
        CELL_OPEN, CELL_CLOSE, CELL_DELETE
    }
}